@echo off
:: ============================================================
::  Scout-2 Daily Runner + GitHub Push
::  Investing with SPACE System
::  GitHub: https://github.com/StacheHistory/scout2-data
:: ============================================================

title Scout-2 Runner

echo.
echo ============================================================
echo  Scout-2 Fetcher + GitHub Push
echo  %DATE% %TIME%
echo ============================================================
echo.

:: ── Step 1: Navigate to Scout2 folder ───────────────────────
cd C:\InvestingWithSPACE\Scout2

if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Could not find C:\InvestingWithSPACE\Scout2
    echo Check that the folder exists.
    pause
    exit /b 1
)

:: ── Step 2: Run the Scout-2 fetcher ─────────────────────────
echo [1/3] Running Scout-2 fetcher...
echo.
py scout2_fetcher_v3.py --days 3

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Fetcher failed. Check Python installation.
    pause
    exit /b 1
)

:: ── Step 3: Stage the output files ──────────────────────────
echo.
echo [2/3] Staging files for GitHub...
git add scout2_dump.json scout2_dump.txt

if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] git add failed. Is this folder a git repo?
    echo Run setup_github.bat first.
    pause
    exit /b 1
)

:: ── Step 4: Commit with timestamp ───────────────────────────
git commit -m "Update Scout-2 feed data — %DATE% %TIME%"

if %ERRORLEVEL% NEQ 0 (
    echo [WARN] Nothing new to commit — data unchanged since last run.
    echo This is normal if feeds have not updated.
    goto done
)

:: ── Step 5: Push to GitHub ───────────────────────────────────
echo.
echo [3/3] Pushing to GitHub...
git push

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Push failed. Check your internet connection
    echo or re-run setup_github.bat to fix credentials.
    pause
    exit /b 1
)

:done
echo.
echo ============================================================
echo  Done. Scout-2 data live at:
echo  https://raw.githubusercontent.com/StacheHistory/scout2-data/main/scout2_dump.json
echo  https://raw.githubusercontent.com/StacheHistory/scout2-data/main/scout2_dump.txt
echo ============================================================
echo.
